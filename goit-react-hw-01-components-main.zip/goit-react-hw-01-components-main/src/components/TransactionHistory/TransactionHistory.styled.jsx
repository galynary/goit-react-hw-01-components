import styled from "@emotion/styled";

export const TrasactionTable = styled.table`
width: 100%;
thead{
	background-color: #71c8f2;
	height:40px;
	
}

tbody {
	tr{
		text-align: center;
		td{
			font-size: 19px;
			height:40px;
			// background-color: white;
		}
	}
}

`;

